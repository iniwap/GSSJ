//
//  IMOBFApiComponent.h
//  MOBFoundation
//
//  Created by 冯鸿杰 on 2017/4/25.
//  Copyright © 2017年 MOB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMOBFServiceComponent.h"

/**
 MobApi产品组件
 */
@protocol IMOBFApiComponent <IMOBFServiceComponent>

@end
